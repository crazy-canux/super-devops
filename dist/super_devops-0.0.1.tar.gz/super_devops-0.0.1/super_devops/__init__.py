#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SUMMARY __init__.py

Copyright (C) 2017 Canux CHENG.
All rights reserved.

LICENSE GNU General Public License v3.0.

:author: Canux CHENG canuxcheng@gmail.com
:version: 0.0.1
:since: Wed 01 Nov 2017 09:13:48 AM EDT

DESCRIPTION:
"""

__version__ = "0.0.1"
__author__ = "Canux CHENG"
